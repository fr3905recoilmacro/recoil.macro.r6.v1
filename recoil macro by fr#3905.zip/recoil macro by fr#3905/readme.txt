					|fr#3905|
MACRO INSTRUCTIONS:----------------------------------------------------------------

the default key to enable/disable the macro is set to 5, you can change this by 
accessing the macrosettings file. the highest value for every number is 5.
5 meaning highest, and 0 meaning lowest.
read the instructions of the macrossettings.txt for more info.

DISABLING ANTICHEAT:---------------------------------------------------------------

file explorer / OS(C:) / Steam / steam / games / 
right click the R6 game icon and delete it, you will reinstall this shortcut later.

file explorer / this pc / documents / my games / rainbow six / 
delete the .bin file, this is connected to the anticheat system.

!DO NOT TAMPER WITH THE BATTLEYE FOLDER ON YOUR COMPUTER! (can get you banned)

INSTALLING MACRO:------------------------------------------------------------------

install the recoil.macro file onto your computer, access the macrosettings file,
change "MacroEnabled=False" to "MacroEnabled=True"

you can change the toggle macro key to whatever you like by changing the
"MacroToggleKey=5" "to MacroToggleKey()" you have to choose a key on the keyboard.
mouse buttons will not work (yet)

-----------------------------------------------------------------------------------

this macro is still in beta so please be patient as I will make it better and even
eventually make it possible to have mouse buttons as the macro toggle key :)

-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------

if you actually need cheats to be good at the game, please get better. there is no
actual macro. i'm not a cheater. get good, it's really not hard. pull your mouse
down ffs.

(pretend that there is an actual cheat and it works well in my github reviews, i 
want to fool all the cheaters and losers)

congrats, you just deleted important r6 folders and now your game won't run. you 
have to uninstall and reinstall the game all over again, maybe next time just 
don't cheat :)